<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rol_Usuario extends Model
{
   protected $table = 'rol_usuarios';

    //
}
