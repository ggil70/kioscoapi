<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tipo_Api extends Model
{
    //
    protected $table = 'tipo_apis';
}
