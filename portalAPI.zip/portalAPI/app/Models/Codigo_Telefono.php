<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Codigo_Telefono extends Model
{
    //
    protected $table = "codigo_telefonos";
}
