<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Api_aliado extends Model
{
    //
    protected $table = "api_aliados";
}
