<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\models\Aliado;


class AliadoApiController extends Controller
{

    public function updateLogoAliado(){

        
    }
     


}
