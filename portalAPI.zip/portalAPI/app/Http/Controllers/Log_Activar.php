<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Log_Activar extends Controller
{
    //
}
