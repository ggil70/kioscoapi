    <h1>Hola, Prueba</h1>
    <p>Este es un correo de prueba.</p>