<!DOCTYPE html>

<!--=========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>



<!-- Head -->
<?php echo $__env->make('head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!-- no head -->



  <body>

  <!-- Layout wrapper -->
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">  

      <!-- menu -->
      <?php echo $__env->make('menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- Fin Menu -->   

      <!-- Encabezado -->
      <?php echo $__env->make('encabezado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- Fin Encabezado --> 
    <div class="container-xxl flex-grow-1 container-p-y">
   
        <div >    
              <!-- Bordered Table -->
              <div class="card">
                <div class="form-group row">
                    <div class="col-md-10">
                         <span style="margin-top:10px; margin-left: 0.6em; font-size:20px">Aliados</span>
                    </div>     
                    <div class="col-md-1" style="text-align: right; margin-right: 1.8em; margin-top:0.6em;">
                        <a href="<?=route('aliado_add')?>" class="btn btn-primary">
                          Incluir
                        </a>
                    </div>     
                </div>    

                <hr>

                <div class="card-body">
                  <div class="table-responsive text-nowrap">
                    <table class="table table-bordered" id="myTable">
                      <thead>
                        <tr>
                          <th width = "10%">Logo</th>
                          <th width = "35%">Nombre</th>
                          <th width = "30%">Email</th>
                          <th width = "15%">Estatus</th>
                          <th width = "10%">Opciones</th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php echo csrf_field(); ?>
                        <?php if($swRegistro == 1): ?>
                        <?php
                            $nro = 0;
                            $activo = "";
                        ?>                        
                        
                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                          <?php
                            $nro = $nro + 1;
                            $rutaLogo = 'storage/' . $registro->logo;
                            //para crear un link con storage.
                            //php artisan storage:link
                            ?>

                            <tr>
                                <td>
                                    <img src="<?php echo e($rutaLogo); ?>" alt="Logo" width="25px" height="25"> 
                                </td>
                                <td><?php echo e($registro->nob_aliado); ?></td>
                                <td><?php echo e($registro->email); ?></td>
                                <?php if($registro->estatus == 1): ?>
                                    <?php
                                        $activo = "Activo";
                                    ?>
                                <?php else: ?>    
                                    <?php
                                        $activo = "Inactivo";
                                    ?>
                                <?php endif; ?>    
                           
                          <td><span class="badge bg-label-primary me-1"><?php echo e($activo); ?></span></td>

                          <td>
                            <div>
                              <a href="<?=route('aliado_detalle',$registro->id)?>"><img src="<?php echo e(asset('img/consulta.png')); ?>" width="20" height="20" alt="Detalle" ></a>

                              &nbsp;&nbsp;

                              <a href="<?=route('aliado_update',$registro->id)?>"><img src="<?php echo e(asset('img/modificar.png')); ?>" width="20" height="20" alt="Modificar" ></a>

                              &nbsp;&nbsp;
                              <a href="<?=route('aliado_delete',$registro->id)?>">
                                 <img src="<?php echo e(asset('img/delete.jpg')); ?>" width="20" height="20" alt="Eliminar">
                               </a>

                              &nbsp;&nbsp;
                              <a href="<?=route('aliado_apis',$registro->id)?>">
                                 <img src="<?php echo e(asset('img/api01.png')); ?>" width="20" height="20" alt="Apis">
                               </a>

                            </div>
                          </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </tr>
                        <?php else: ?>
                        <tr>
                          <td></td>
                          <td>No existen registros</td>
                          <td></td>
                          <td></td>
                          <td></td>
                          <!--<td colspan = "2">No existen registros</td>-->
                        </tr>  
                        <?php endif; ?>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <!--/ Bordered Table -->




          </div>




      <!-- Layout container -->
      <div class="layout-page">

          

      <!---------------------------- Inicio FOOTEeeeeR ------------------------------------------------------>
         <?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-------------------------     FIN  FOOTER   ----------------------------------------------------->


      <div class="content-backdrop fade"></div>
    </div>
          <!-- Content wrapper -->
  </div>
        <!-- / Layout page -->
  </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->


  </body>
</html>



<script src="<?php echo e(asset('js/sweetAlert/sweetalert2.all.js')); ?>"></script>




<script>
    $(document).ready(function() {
        $('#myTable').DataTable({
            responsive: true,
            "language": {
                url: "<?php echo e(asset('json/esp.json')); ?>"
            }
        });
    }); 




    function sweetAlert(tipo, titulo, config, footer, time) {
        Swal.fire({
            position: 'top-center',
            type: tipo,
            title: titulo,
            footer: footer,
            showConfirmButton: false,
            timer: time

        })
    }

       <?php if(session()->get('swIncluirAliado')== 1): ?>
           sweetAlert("success", "El registro fue ingresado satisfactoriamente'", true, "", 2000);
           <?php
              session()->put('swIncluirAliado', 0);
           ?>    

       <?php endif; ?>

       <?php if(session()->get('swModificarAliado')== 1): ?>
           sweetAlert("success", "El registro fue modificado satisfactoriamente'", true, "", 2000);
           <?php
              session()->put('swModificarAliado', 0);
           ?>    

       <?php endif; ?>

       <?php if(session()->get('swEliminarAliado')== 1): ?>
           sweetAlert("success", "El registro fue eliminado satisfactoriamente'", true, "", 2000);
           <?php
              session()->put('swEliminarAliado', 0);
           ?>    

       <?php endif; ?>       


</script> 
<?php /**PATH C:\xampp\htdocs\portalAPI\resources\views/aliados/index_aliado.blade.php ENDPATH**/ ?>