    <h1>Hola, Prueba</h1>
    <p>Este es un correo de prueba.</p><?php /**PATH C:\xampp\htdocs\portalAPI\resources\views/emails/micorreo.blade.php ENDPATH**/ ?>